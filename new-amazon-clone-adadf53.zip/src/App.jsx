// import ImageCarousel from "./Components/Carousel/ImageCarousel"
// import Category from "./Components/Category/Category"
// import Header from "./Components/Header/Header"
// import Product from "./Components/Products/Product"
import Routing from "./Router.jsx"

function App() {
  

  return (
    <>

    <Routing/> 
    </>
  )
}

export default App
