
import img1 from './001.jpg'
import img2 from './002.jpg'
import img3 from './003.jpg'
import img4 from './004.jpg'
import img5 from './005.jpg'


export const img = [ img1, img2, img3, img4, img5 ];
