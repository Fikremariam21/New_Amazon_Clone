// https://fakestoreapi.com/products/category/electronics/


export const categoryInfos = [
    {
      title: "Electronics",
      name: "electronics",
      imgLink:
        "https://fakestoreapi.com/img/61IBBVJvSDL._AC_SY879_.jpg",  
    },
    {
      title: "Discover fashion trends",
      name: "women's clothing",
      imgLink:
        "https://fakestoreapi.com/img/51eg55uWmdL._AC_UX679_.jpg",  
    },
    {
      title: "Men's Clothing",
      name: "men's clothing",
      imgLink:
        "https://fakestoreapi.com/img/71-3HjGNDUL._AC_SY879._SX._UX._SY._UY_.jpg",  
    },
    {
      title: "Jewelery",
      name: "jewelery",
      imgLink:
        "https://fakestoreapi.com/img/71YAIFU48IL._AC_UL640_QL65_ML3_.jpg",
    },
  ];