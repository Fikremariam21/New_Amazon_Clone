import React from 'react'
import styles from './Orders.module.css'
import LayOut from '../../Components/LayOut/LayOut'
const Orders = () => {
  return (
    <LayOut> 
    <div>
        Orders

    </div>
    </LayOut>
  )
}

export default Orders