import React from 'react'
import styles from './Payment.module.css'
import LayOut from '../../Components/LayOut/LayOut'
const Payment = () => {
  return (
    <LayOut> 
    <div>
        Payment
    </div>
    </LayOut>
  )
}

export default Payment