import React from 'react'
import LayOut from '../../Components/LayOut/LayOut'

const ProductDetail = () => {
  return (
    <LayOut> 
    <div>
        ProductDetail
    </div>
    </LayOut>
  )
}

export default ProductDetail