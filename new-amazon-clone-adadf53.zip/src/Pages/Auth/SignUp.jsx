import React from 'react'
import styles from './SignUp.module.css'
import LayOut from '../../Components/LayOut/LayOut'
const SignUp = () => {
  return (
    <LayOut> 
    <div>
        SignUp
    </div>
    </LayOut>
  )
}

export default SignUp