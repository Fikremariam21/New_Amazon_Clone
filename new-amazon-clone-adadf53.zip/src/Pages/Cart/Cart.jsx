import React from 'react'
import styles from './Cart.module.css'
import LayOut from '../../Components/LayOut/LayOut'
const Cart = () => {
  return (
    <LayOut> 
    <div>
        Cart
    </div>
    </LayOut>
  )
}

export default Cart